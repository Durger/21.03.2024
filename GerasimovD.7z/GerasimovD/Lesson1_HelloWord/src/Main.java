public class main {

    public static void main(string[] args) {
    int invatie = 10000
    long longfromint  = inwali;

    double doublaver = 3, 14159
     double doubladgject = double voluedf(daulavel);

    System. out. println("'это значения переменной dubledjct") "doubledojct; "doubled0bjekt
         double double vetie = invalue;
    Sustem. out. prinln(doublevalie);

    String doublevelbirstring = "3";
    double doublefromstring = double. parsedouble(doublevabursting);
    int infromsting = intiger/ parselnt(doublevalbusstring)

    System.out. println(doublefromsting);
    System. out. prinln(infromsting);

// inter sum = new intager (2) + new integer
         int sum = 2 + 3;
         System. out. println(sum);

         Scanner. scanner = new Scanner(System. in);
         System.out. printic("введите информации; ");
         System.out. println(info);
         // reverse()-переварачивать строку
        //delate(x,y)-удаляет символы между указанными индексами

    stringbuilder sbAppend = new











