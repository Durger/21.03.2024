import java.util.concurrent.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {
    public static void main(String[] args) {

        //Пример1
      /*  ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.execute(()->{
            String threaderName = Thread.currentThread().getName();
            try {
               Thread.currentThread().sleep(5000);

            }
            catch (InterruptedException e){
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE,null, e);
            }
            System.out.println("hello from" + threaderName);
        });
        executor.execute(()->{
        String threaderName = Thread.currentThread().getName();
            System.out.println("hello again from " + threaderName);
        });
        executor.shutdown();*/

        //Пример2
        /*ExecutorService executor = Executors.newSingleThreadExecutor();
        Future future = executor.submit(new Runnable() {
            @Override
            public void run() {
            String  threaderName = Thread.currentThread().getName();
                System.out.println("this code doing executor " + "asynchronously in thread" + threaderName);
            }
        });
        try {
            if(future.get()==null){
                System.out.println("Success!");
            }
        } catch (InterruptedException e){
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE,null, e);
        } catch (ExecutionException e){
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE,null, e);
         }
            executor.shutdown();*/


        //Пример3 - Запланированные исполнители(ScheduledExecutor)
        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1); //дополнит потоки
        Runnable task = new Runnable() {
            @Override
            public void run() {
                System.out.println("hello from " + Thread.currentThread().getName());
            }
        };
        ScheduledFuture sf = executor.scheduleAtFixedRate(task,0,2,TimeUnit.SECONDS); //параметры
        try {
            Thread.currentThread().sleep(5000);
        }
        catch (InterruptedException e){
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE,null, e);
        }
        sf.cancel(true); //закрытие основного потока
        try {
            //Thread.currentThread().sleep(5000);
            System.out.println("Attempt to shutdown executor ");
            executor.shutdown();
            executor.awaitTermination(3, TimeUnit.SECONDS);
        }
        catch (InterruptedException e){
            //Logger.getLogger(Main.class.getName()).log(Level.SEVERE,null,e);
            System.out.println("Task interrupt");
        }
        finally {
            if(!executor.isTerminated()){
                executor.shutdown();
                System.out.println("Make is to stop");
            }
            System.out.println("Shutdown finished");
        }
      /*  sf.cancel(true);
        System.out.println("the end");*/

    }
}