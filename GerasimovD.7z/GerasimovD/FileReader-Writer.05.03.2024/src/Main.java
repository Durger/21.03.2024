import java.io.*;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {
    public static void main(String[] args) {

        //Пример.1. Замена одного значения другим
       /* FileReader fr = null;
        FileWriter fw = null;
        try {
            fr = new FileReader("lines.txt");
            fw = new FileWriter("lines1.txt");
            BufferedReader br = new BufferedReader(fr);
            String line = "";
            int lineCount = 0;
            while ((line = br.readLine())!= null){
            if ((lineCount++)%2==0){
                    System.out.println(line);
                    line = line.replace('h', 'H');
                    fw.write((line + System.getProperty("line.separator")));
                }
               //fw.write(line + System.getProperty("line.separator"));
            }
        }
        catch (FileNotFoundException e){
            Logger.getLogger((File.class.getName())).log(Level.SEVERE, null, e);
        }
        catch (IOException e){
            Logger.getLogger((File.class.getName())).log(Level.SEVERE, null, e);
        }
        finally {
            try {
                fr.close();
                fw.close();
            } catch (IOException e) {
                Logger.getLogger((File.class.getName())).log(Level.SEVERE, null, e);
            }
        }*/

        //Пример.2.Изменение кодировки входных и выходных данных
        /*try (FileInputStream fis = new FileInputStream(new File("lines.txt"));
             InputStreamReader reader = new InputStreamReader(fis,"windows-1251");
             FileOutputStream fs = new FileOutputStream(new File("lines1.txt"));
             OutputStreamWriter writer = new OutputStreamWriter(fs, "UTF-8")) {
            int c;
            while((c=reader.read())!=-1){
                System.out.print((char) c);
                writer.write(c);
            }
        }catch(FileNotFoundException e) {
            Logger.getLogger((File.class.getName())).log(Level.SEVERE, null, e);
        }catch(IOException e){
                Logger.getLogger((File.class.getName())).log(Level.SEVERE, null, e);
            }*/


        //Пример.3.System.in
     /*   BufferedReader inp = new BufferedReader(new InputStreamReader(System.in));
        String line = inp.readLine();*/


        //Пример.4.
      /*  try{
            System.setOut(new PrintStream(new FileOutputStream("out.txt")));
            System.out.println("File now");
            throw new Exception();                  //вызов ошибки
        }
        catch (Exception e){
            System.out.println("File error!!!!!!!");
            e.printStackTrace();                      //сообщение о месте нахождения ошибки
        }*/



        //Практика.25. Задача.1.
        //Пользователь с клавиатуры вводит путь к файлу. После чего содержимое файла отображается на экране.

        //Задача.2. К первому заданию добавить поэкранный вывод, если содержимое файла не помещается на экране.
        BufferedReader reader = null;
        try{
            System.out.println("Wright path to file: ");
            Scanner scanner = new Scanner(System.in);
            String filePath = scanner.nextLine();
            scanner.close();
            reader = new BufferedReader(new FileReader(filePath));
            String line = "";
            int lineNumber = 1;
            while ((line = reader.readLine()) != null){
                System.out.println(line);
                lineNumber++;
                if(lineNumber % 20 == 0){
                    System.out.println("Push the Enter for continue: ");
                    System.console().readLine();
                }
            }
        }
        catch (IOException e){
            System.out.println("File reader error: " + e.getMessage());
        }
        finally {
            try {
                if (reader != null){
                    reader.close();
                }
            }
            catch (IOException e){
                System.out.println("File reader error: " + e.getMessage());
            }
        }



    }
}